# Tow1 私人网盘部署教程

本文适用于随部署包交付的 Tow1 私人网盘。推荐使用 **Vercel + Turso + 腾讯云 COS**：Vercel 运行应用，Turso 保存文件索引和分享记录，COS 保存文件本体。

> 部署包不包含任何真实密码、云密钥、数据库文件或已上传文件。首次部署前必须自行配置环境变量。

## 一、部署前准备

准备以下账号和资源：

1. Node.js 20 LTS 或更新的 LTS 版本，以及 npm。
2. 一个私有读写的腾讯云 COS 存储桶，记下存储桶名称、地域、SecretId 和 SecretKey。
3. 生产环境推荐准备一个 Turso/libSQL 数据库，记下数据库 URL 和访问令牌。
4. 一个用于访问网盘的域名。没有自定义域名时，可以先使用 Vercel 分配的域名。

解压部署包后，应能看到 `package.json`、`package-lock.json`、`app/`、`components/`、`lib/`、`public/` 和本教程。包内不应出现 `.env.local`、`data/drive.sqlite`、`.next/`、`node_modules/` 或日志文件。

## 二、环境变量

复制 `.env.example` 为 `.env.local`（本地或自托管）或在托管平台的环境变量页面逐项填写。不要把填写后的环境变量文件提交到 Git 或发送给他人。

| 变量 | 必填 | 说明 |
| --- | --- | --- |
| `DRIVE_USERNAME` | 否 | 登录用户名，默认 `owner` |
| `DRIVE_PASSWORD` | 二选一 | 明文登录密码；仅适合快速部署 |
| `DRIVE_PASSWORD_HASH` | 二选一 | 推荐使用的 scrypt 密码哈希 |
| `DRIVE_SESSION_SECRET` | 是 | 会话与分享签名密钥，必须是高强度随机值 |
| `DRIVE_TURSO_DATABASE_URL` | 生产必填 | Turso/libSQL 数据库 URL，例如 `libsql://...` |
| `DRIVE_TURSO_AUTH_TOKEN` | 生产必填 | Turso 数据库访问令牌 |
| `DRIVE_COS_SECRET_ID` | 是 | 腾讯云 API SecretId |
| `DRIVE_COS_SECRET_KEY` | 是 | 腾讯云 API SecretKey |
| `DRIVE_COS_BUCKET` | 是 | 完整存储桶名，通常包含 AppId |
| `DRIVE_COS_REGION` | 是 | COS 地域，例如 `ap-bangkok` |
| `DRIVE_COS_PREFIX` | 否 | COS 对象前缀，默认 `tow1/files/` |
| `NEXT_PUBLIC_APP_URL` | 是 | 正式访问地址，不带末尾斜杠 |
| `NEXT_PUBLIC_MAX_UPLOAD_MB` | 否 | 单文件上传上限，默认示例为 5120MB |
| `NEXT_PUBLIC_STORAGE_QUOTA_GB` | 否 | 页面显示的总容量 |
| `DRIVE_MAX_ZIP_MB` | 否 | 分享文件夹打包下载上限，默认 100MB |

生成会话密钥（任选一种）：

```bash
openssl rand -hex 32
```

```powershell
[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLower()
```

生成推荐的密码哈希：

```powershell
node -e "const c=require('node:crypto');const s=c.randomBytes(16).toString('hex');console.log(['scrypt',s,c.scryptSync(process.argv[1],s,32).toString('hex')].join(String.fromCharCode(36)))" "替换为你的密码"
```

将输出完整填入 `DRIVE_PASSWORD_HASH`，并让 `DRIVE_PASSWORD` 保持为空。若修改了任何生产环境变量，必须重新构建或重新部署应用。

## 三、配置腾讯云 COS

1. 创建存储桶并保持“私有读写”。不要配置公共读权限。
2. 创建权限尽可能小的 API 密钥。它至少需要在指定存储桶和 `DRIVE_COS_PREFIX` 下上传、分片上传、读取和删除对象的权限。
3. 在存储桶的“安全管理 → 跨域访问 CORS”添加规则：
   - 来源 Origin：生产域名，例如 `https://drive.example.com`；本地调试时另加 `http://localhost:3000`。
   - 方法：`PUT`、`GET`、`HEAD`。
   - Allowed-Headers：`*`。
   - Expose-Headers：`ETag`、`Content-Length`。
4. 确认 `DRIVE_COS_BUCKET` 是完整存储桶名，`DRIVE_COS_REGION` 与控制台显示的地域代码一致。

浏览器会使用服务端生成的短期签名 URL 直传 COS。SecretKey 只能配置在服务端环境变量中，绝不能加上 `NEXT_PUBLIC_` 前缀。

## 四、配置 Turso/libSQL

新建数据库后，将数据库 URL 与令牌分别填入 `DRIVE_TURSO_DATABASE_URL` 和 `DRIVE_TURSO_AUTH_TOKEN`。应用首次访问时会自动创建所需数据表和索引，不需要手动执行 SQL 迁移。

若这两个变量留空，应用会在工作目录下创建 `data/drive.sqlite`。这种方式只适合单机、有持久磁盘的部署；Vercel 等无状态/临时文件系统必须使用 Turso。多实例自托管也应使用远程数据库。

## 五、方案 A：部署到 Vercel（推荐）

1. 将解压后的源码放入一个私有 Git 仓库，并在 Vercel 中导入该仓库；也可以使用 Vercel CLI 从目录部署。
2. Framework Preset 选择 Next.js。构建命令保持 `npm run build`，安装命令保持 `npm ci` 或平台默认值。
3. 在 Project Settings → Environment Variables 中填写“二、环境变量”的生产配置，至少应用到 Production。
4. 触发一次 Production 部署。
5. 在 Domains 中绑定正式域名，然后把 `NEXT_PUBLIC_APP_URL` 更新为该域名并重新部署。
6. 回到 COS CORS 配置，确保正式域名已经加入允许来源。

部署完成后依次验证：登录、创建文件夹、上传小文件、刷新后仍可见、预览/下载、创建带密码和有效期的分享、访客解锁下载、移入回收站与恢复。最后再测试永久删除；它会同步删除数据库记录与 COS 对象，操作不可撤销。

## 六、方案 B：自托管 Linux + systemd + Nginx

以下示例假设应用位于 `/opt/tow1`，由普通系统用户 `tow1` 运行，监听本机 3000 端口。

### 1. 安装和构建

```bash
cd /opt/tow1
cp .env.example .env.local
nano .env.local
npm ci
npm run check
```

`npm run check` 会先执行 TypeScript 类型检查，再执行生产构建。全部通过后再配置服务。

### 2. 创建 systemd 服务

新建 `/etc/systemd/system/tow1.service`：

```ini
[Unit]
Description=Tow1 Private Drive
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=tow1
Group=tow1
WorkingDirectory=/opt/tow1
Environment=NODE_ENV=production
Environment=PORT=3000
ExecStart=/usr/bin/npm run start
Restart=on-failure
RestartSec=5
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

如果 `node` 或 `npm` 不是安装在 `/usr/bin`，先运行 `command -v npm`，再替换 `ExecStart` 中的路径。启用服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now tow1
sudo systemctl status tow1
```

查看运行日志：

```bash
journalctl -u tow1 -n 200 --no-pager
```

### 3. 配置 Nginx

创建站点配置并将域名替换成自己的：

```nginx
server {
    listen 80;
    server_name drive.example.com;

    client_max_body_size 20m;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
    }
}
```

文件本体由浏览器直传 COS，因此 Nginx 的请求体上限通常不会限制大文件上传；它仍需足够容纳普通 API 请求。检查配置、重载 Nginx，再使用 Certbot 或现有证书方案启用 HTTPS。正式环境必须使用 HTTPS，否则安全 Cookie 无法正常工作。

若使用本地 SQLite，请确保 `/opt/tow1/data` 对 `tow1` 用户可写，并将该目录纳入持久化与备份。不要在多个应用实例之间共享普通网络文件系统上的 SQLite 文件。

## 七、升级与回滚

升级前先备份数据库；COS 文件本体也应配置版本控制、生命周期或额外备份策略。推荐使用“新目录构建、成功后切换”的方式：

1. 解压新版本到新目录，复制旧部署的环境变量配置，但不要复制 `.next` 或 `node_modules`。
2. 执行 `npm ci` 和 `npm run check`。
3. 停止旧服务，将 systemd 的 `WorkingDirectory` 切换到新目录并启动。
4. 完成登录、列表、上传和下载冒烟测试后再删除旧版本。

回滚应用代码时仍应使用升级前的数据库备份进行风险控制。数据库结构由应用自动向前补齐，旧代码未必理解新版本写入的数据结构。

## 八、备份范围

- 使用 Turso：按服务商能力配置数据库备份/时间点恢复，并定期验证恢复流程。
- 使用本地 SQLite：停止写入后备份 `data/drive.sqlite`，或使用 SQLite 的在线备份机制；不要只复制正在高频写入的文件。
- COS：数据库只保存对象键与元数据，真正文件位于 COS。数据库备份不能替代 COS 备份。
- 环境变量：加密保存一份，但不要放进源码包、Git 仓库或普通网盘共享链接。

## 九、常见问题

### 启动时报“缺少 DRIVE_SESSION_SECRET”

生产环境未设置会话密钥，或修改变量后没有重新部署/重启。生成随机值、保存变量并重新部署。

### 登录一直失败

确认配置的是 `DRIVE_PASSWORD` 或格式完整的 `DRIVE_PASSWORD_HASH`，用户名与 `DRIVE_USERNAME` 一致。避免在环境变量值两端误加引号或空格。

### 上传时报 CORS、403 或签名错误

核对 COS 来源域名、存储桶完整名称、地域、密钥权限和服务器时间。浏览器开发者工具中的失败请求应指向 COS 域名；若刚切换域名，记得同时更新 COS CORS 和 `NEXT_PUBLIC_APP_URL`。

### Vercel 部署后文件列表消失或数据库报错

确认已配置 `DRIVE_TURSO_DATABASE_URL` 与 `DRIVE_TURSO_AUTH_TOKEN`。Vercel 的本地文件系统不能用作持久数据库。

### 分享链接域名不正确

把 `NEXT_PUBLIC_APP_URL` 改成包含 `https://` 的正式域名，去掉末尾斜杠，然后重新部署。

### 自托管返回 502

检查 `systemctl status tow1` 和 `journalctl -u tow1`，确认应用监听 3000 端口，再检查 Nginx 的 `proxy_pass`。若端口被占用，可设置不同的 `PORT` 并同步修改 Nginx。

## 十、上线验收清单

- [ ] 压缩包中不存在 `.env.local`、数据库、日志、`.git`、`.next`、`node_modules`。
- [ ] `npm ci`、`npm run typecheck`、`npm run build` 全部通过。
- [ ] 正式地址为 HTTPS，`NEXT_PUBLIC_APP_URL` 与实际地址一致。
- [ ] COS 保持私有读写，CORS 只允许需要的站点来源。
- [ ] 登录、上传、刷新、预览、下载、分享、回收站均已测试。
- [ ] 数据库和 COS 均有备份策略，且恢复步骤已验证。
- [ ] 密钥未进入源码仓库、构建日志或部署压缩包。
